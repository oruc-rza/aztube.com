import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { db } from './src/db/index.ts';
import { videos, channels, comments, users } from './src/db/schema.ts';
import { eq, desc, sql } from 'drizzle-orm';
import { getOrCreateUser } from './src/db/users.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '100mb' }));

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', platform: 'AzTube', timestamp: new Date().toISOString() });
});

// Sync / create user in Cloud SQL upon sign-in
app.post('/api/users/sync', requireAuth, async (req: AuthRequest, res: express.Response) => {
  try {
    const { uid, email } = req.user!;
    const { name, photoUrl } = req.body;
    const user = await getOrCreateUser(uid, email || '', name, photoUrl, 'creator');
    res.json({ success: true, user });
  } catch (error: any) {
    console.error('Failed to sync user:', error);
    res.status(500).json({ error: 'İstifadəçi məlumatları sinxronlaşdırılmadı' });
  }
});

// Videos API: open for all users
app.get('/api/videos', async (_req, res) => {
  try {
    const list = await db.select().from(videos).orderBy(desc(videos.createdAt));
    res.json(list);
  } catch (error: any) {
    console.error('Error fetching videos from Cloud SQL:', error);
    res.status(500).json({ error: 'Videolar yüklənmədi' });
  }
});

app.get('/api/videos/:id', async (req, res) => {
  try {
    const rows = await db.select().from(videos).where(eq(videos.id, req.params.id));
    if (!rows.length) {
      return res.status(404).json({ error: 'Video tapılmadı' });
    }
    res.json(rows[0]);
  } catch (error: any) {
    console.error(`Error fetching video ${req.params.id}:`, error);
    res.status(500).json({ error: 'Video yüklənmədi' });
  }
});

// Upload Video: Any signed in Google user can upload!
app.post('/api/videos', async (req: express.Request, res: express.Response) => {
  try {
    const v = req.body;
    if (!v.id || !v.title || !v.videoUrl) {
      return res.status(400).json({ error: 'Video məlumatları natamamdır' });
    }

    const [saved] = await db
      .insert(videos)
      .values({
        id: v.id,
        title: v.title,
        description: v.description || '',
        videoUrl: v.videoUrl,
        thumbnailUrl: v.thumbnailUrl,
        duration: v.duration || '05:00',
        channelId: v.channelId,
        channelName: v.channelName,
        channelAvatar: v.channelAvatar || null,
        channelHandle: v.channelHandle || null,
        category: v.category || 'Ümumi',
        views: v.views || 0,
        likes: v.likes || 0,
        dislikes: v.dislikes || 0,
      })
      .onConflictDoUpdate({
        target: videos.id,
        set: {
          title: v.title,
          description: v.description || '',
          thumbnailUrl: v.thumbnailUrl,
          category: v.category || 'Ümumi',
        },
      })
      .returning();

    res.json({ success: true, video: saved });
  } catch (error: any) {
    console.error('Error inserting video in Cloud SQL:', error);
    res.status(500).json({ error: 'Video bazaya yazıla bilmədi' });
  }
});

// Delete Video
app.delete('/api/videos/:id', async (req: express.Request, res: express.Response) => {
  try {
    await db.delete(videos).where(eq(videos.id, req.params.id));
    res.json({ success: true });
  } catch (error: any) {
    console.error(`Error deleting video ${req.params.id}:`, error);
    res.status(500).json({ error: 'Video silinmədi' });
  }
});

// Increment views
app.post('/api/videos/:id/view', async (req, res) => {
  try {
    await db
      .update(videos)
      .set({ views: sql`${videos.views} + 1` })
      .where(eq(videos.id, req.params.id));
    res.json({ success: true });
  } catch {
    res.status(200).json({ success: false });
  }
});

// Channel Info
app.get('/api/channels/:id', async (req, res) => {
  try {
    const rows = await db.select().from(channels).where(eq(channels.id, req.params.id));
    if (!rows.length) {
      return res.status(404).json({ error: 'Kanal tapılmadı' });
    }
    res.json(rows[0]);
  } catch (error: any) {
    console.error('Error getting channel:', error);
    res.status(500).json({ error: 'Kanal tapılmadı' });
  }
});

// Setup Vite or static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
