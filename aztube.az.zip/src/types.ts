export interface Video {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: string;
  channelId: string;
  channelName: string;
  channelAvatar?: string;
  channelHandle?: string;
  category: string;
  views: number;
  likes: number;
  dislikes: number;
  createdAt: string;
}

export interface Channel {
  id: string; // User UID
  name: string;
  handle: string;
  avatar?: string;
  bannerUrl?: string;
  bio?: string;
  subscribersCount: number;
  createdAt: string;
}

export interface Comment {
  id: string;
  videoId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  comment: string;
  createdAt: string;
}

export interface Subscription {
  id: string;
  userId: string;
  channelId: string;
  createdAt: string;
}

export interface VideoLike {
  id: string;
  userId: string;
  videoId: string;
  type: 'like' | 'dislike';
  createdAt: string;
}

export interface WatchLaterItem {
  id: string;
  userId: string;
  videoId: string;
  videoTitle: string;
  thumbnailUrl: string;
  createdAt: string;
}

export type CategoryFilter = 
  | 'Hamısı'
  | 'Musiqi'
  | 'Oyunlar'
  | 'Xəbərlər'
  | 'Texnologiya'
  | 'Təhsil'
  | 'Əyləncə'
  | 'Podkastlar'
  | 'Vloq'
  | 'İdman'
  | 'Trendlər';
