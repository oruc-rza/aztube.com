import React from 'react';
import { X, Clock, Play, Trash2 } from 'lucide-react';
import { WatchLaterItem, Video } from '../types';

interface WatchLaterModalProps {
  items: WatchLaterItem[];
  allVideos: Video[];
  onClose: () => void;
  onSelectVideo: (video: Video) => void;
  onRemoveItem: (video: Video) => void;
}

export const WatchLaterModal: React.FC<WatchLaterModalProps> = ({
  items,
  allVideos,
  onClose,
  onSelectVideo,
  onRemoveItem,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#1c1c1c] border border-white/10 rounded-3xl shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">Sonra İzlə</h2>
              <p className="text-xs text-zinc-400">Yadda saxladığınız videolar ({items.length})</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[70vh] overflow-y-auto space-y-3">
          {items.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <Clock className="w-12 h-12 text-zinc-600 mx-auto" />
              <p className="text-zinc-400 text-sm font-medium">Siyahınız boşdur.</p>
              <p className="text-zinc-500 text-xs">
                Videoların üzərindəki 3 nöqtə və ya pleyerdən "Sonra izlə" seçərək bura əlavə edə bilərsiniz.
              </p>
            </div>
          ) : (
            items.map((item) => {
              const matchedVideo = allVideos.find((v) => v.id === item.videoId) || {
                id: item.videoId,
                title: item.videoTitle,
                description: '',
                videoUrl: '',
                thumbnailUrl: item.thumbnailUrl,
                duration: '05:00',
                channelId: '',
                channelName: 'Kanal',
                category: 'Ümumi',
                views: 0,
                likes: 0,
                dislikes: 0,
                createdAt: item.createdAt,
              };

              return (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 transition-all group"
                >
                  <div
                    onClick={() => {
                      onSelectVideo(matchedVideo);
                      onClose();
                    }}
                    className="flex items-center gap-3.5 flex-1 min-w-0 cursor-pointer"
                  >
                    <div className="relative w-28 aspect-video rounded-xl overflow-hidden bg-zinc-900 shrink-0">
                      <img
                        src={item.thumbnailUrl}
                        alt={item.videoTitle}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <Play className="w-5 h-5 text-white fill-current" />
                      </div>
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-white font-bold text-sm truncate group-hover:text-red-400 transition-colors">
                        {item.videoTitle}
                      </h4>
                      <p className="text-xs text-zinc-500 mt-1">
                        Əlavə edildi: {new Date(item.createdAt).toLocaleDateString('az-AZ')}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveItem(matchedVideo)}
                    className="p-2 text-zinc-500 hover:text-red-400 rounded-full hover:bg-red-500/10 transition-colors cursor-pointer"
                    title="Siyahıdan çıxar"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
