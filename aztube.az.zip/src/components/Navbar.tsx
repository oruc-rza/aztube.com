import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Search, 
  Menu, 
  Video as VideoIcon, 
  Bell, 
  User as UserIcon, 
  LogOut, 
  Clock, 
  Tv, 
  CheckCircle2, 
  X,
  Share2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Channel } from '../types';

interface NavbarProps {
  onToggleSidebar: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenUpload: () => void;
  onOpenChannel: (channelId: string) => void;
  onOpenWatchLater: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleSidebar,
  searchQuery,
  onSearchChange,
  onOpenUpload,
  onOpenChannel,
  onOpenWatchLater,
}) => {
  const { user, channel, loginWithGoogle, logout } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchInput, setSearchInput] = useState(searchQuery);
  const menuRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(searchInput);
  };

  const handleClearSearch = () => {
    setSearchInput('');
    onSearchChange('');
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-md border-b border-white/10 px-3 md:px-5 py-2.5 flex items-center justify-between gap-4">
      {/* Left: Hamburger & Logo */}
      <div className="flex items-center gap-3 md:gap-4 shrink-0">
        <button
          onClick={onToggleSidebar}
          aria-label="Menyu"
          className="p-2 text-zinc-300 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        <a href="/" className="flex items-center gap-2 group select-none">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-red-600 to-red-500 flex items-center justify-center shadow-lg shadow-red-600/30 group-hover:scale-105 transition-transform">
            <Play className="w-5 h-5 text-white fill-current ml-0.5" />
          </div>
          <div className="flex items-baseline">
            <span className="text-xl font-black tracking-tight text-white font-['Plus_Jakarta_Sans',sans-serif]">
              Az<span className="text-red-500">Tube</span>
            </span>
            <span className="ml-1 text-[10px] font-bold uppercase tracking-wider text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded border border-red-500/20">
              AZ
            </span>
          </div>
        </a>
      </div>

      {/* Middle: Search Bar */}
      <form
        onSubmit={handleSearchSubmit}
        className="flex-1 max-w-2xl mx-auto flex items-center"
      >
        <div className="relative w-full flex items-center">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Video və ya kanal axtarın..."
            className="w-full bg-[#121212] border border-white/15 focus:border-red-500 text-white placeholder-zinc-500 text-sm rounded-l-full py-2.5 pl-4 pr-10 focus:outline-none focus:ring-1 focus:ring-red-500 transition-all shadow-inner"
          />
          {searchInput && (
            <button
              type="button"
              onClick={handleClearSearch}
              className="absolute right-3 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <button
          type="submit"
          className="bg-white/10 hover:bg-white/15 border border-l-0 border-white/15 text-zinc-300 hover:text-white px-5 py-2.5 rounded-r-full transition-colors flex items-center justify-center cursor-pointer"
          title="Axtar"
        >
          <Search className="w-4 h-4" />
        </button>
      </form>

      {/* Right: Actions & User */}
      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        {/* Upload Button */}
        <button
          onClick={onOpenUpload}
          className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 text-white font-semibold text-xs md:text-sm px-3.5 py-2 rounded-full shadow-md shadow-red-600/20 hover:shadow-red-600/40 transition-all cursor-pointer active:scale-95"
          title="Video Yüklə"
        >
          <VideoIcon className="w-4 h-4" />
          <span className="hidden sm:inline">Video Yüklə</span>
        </button>

        {/* Notifications */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 text-zinc-300 hover:text-white hover:bg-white/10 rounded-full transition-colors relative cursor-pointer"
            title="Bildirişlər"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-[#1c1c1c] border border-white/10 rounded-2xl shadow-2xl p-4 z-50 text-left">
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
                <h4 className="text-white font-bold text-sm">Bildirişlər</h4>
                <span className="text-xs text-red-400">Yeni paylaşımlar</span>
              </div>
              <div className="space-y-3 text-xs text-zinc-300">
                <div className="flex gap-3 p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                  <div className="w-8 h-8 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                    <VideoIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-white font-medium">Xoş gəlmisiniz!</p>
                    <p className="text-zinc-400 mt-0.5">Google ilə daxil olub öz kanalınızı qura və videolarınızı dərhal paylaşa bilərsiniz.</p>
                  </div>
                </div>
                <div className="flex gap-3 p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                    <Tv className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-white font-medium">Real-Vaxt İzləmə</p>
                    <p className="text-zinc-400 mt-0.5">İstifadəçilərin paylaşdığı videolar dərhal ana səhifədə görünür.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Auth / Channel Menu */}
        {user ? (
          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-red-500/50 transition-all cursor-pointer"
            >
              <img
                src={channel?.avatar || user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'}
                alt={user.displayName || 'İstifadəçi'}
                className="w-8 h-8 md:w-9 md:md-9 rounded-full object-cover border border-white/20"
              />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-72 bg-[#1c1c1c] border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-50">
                {/* Header Profile preview */}
                <div className="p-4 bg-gradient-to-b from-white/10 to-transparent border-b border-white/10">
                  <div className="flex items-center gap-3">
                    <img
                      src={channel?.avatar || user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'}
                      alt=""
                      className="w-12 h-12 rounded-full object-cover border-2 border-red-500"
                    />
                    <div className="overflow-hidden">
                      <div className="flex items-center gap-1">
                        <p className="text-white font-bold text-sm truncate">{channel?.name || user.displayName || 'Kanalım'}</p>
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      </div>
                      <p className="text-zinc-400 text-xs truncate">{channel?.handle || user.email}</p>
                      <p className="text-[11px] text-red-400 mt-0.5">{channel?.subscribersCount || 1} abunəçi</p>
                    </div>
                  </div>
                </div>

                {/* Menu items */}
                <div className="p-2 space-y-1 text-sm">
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      if (user) onOpenChannel(user.uid);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-zinc-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer text-left"
                  >
                    <Tv className="w-4 h-4 text-red-400" />
                    <span>Kanalıma bax və redaktə et</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      onOpenWatchLater();
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-zinc-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer text-left"
                  >
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>Sonra izlə siyahısı</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      onOpenUpload();
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-zinc-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer text-left"
                  >
                    <VideoIcon className="w-4 h-4 text-emerald-400" />
                    <span>Yeni video paylaş</span>
                  </button>

                  <div className="border-t border-white/10 my-1"></div>

                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-xl transition-colors cursor-pointer text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Çıxış et</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={() => loginWithGoogle()}
            className="flex items-center gap-2 border border-blue-500/40 hover:bg-blue-500/10 text-blue-400 font-semibold text-xs md:text-sm px-3.5 py-1.5 rounded-full transition-all cursor-pointer"
          >
            <UserIcon className="w-4 h-4" />
            <span>Daxil ol</span>
          </button>
        )}
      </div>
    </header>
  );
};
