import React from 'react';
import { CategoryFilter } from '../types';

interface CategoryBarProps {
  categories: CategoryFilter[];
  activeCategory: CategoryFilter;
  onSelectCategory: (cat: CategoryFilter) => void;
}

export const CategoryBar: React.FC<CategoryBarProps> = ({
  categories,
  activeCategory,
  onSelectCategory,
}) => {
  return (
    <div className="sticky top-[57px] z-20 bg-[#0f0f0f]/95 backdrop-blur-md border-b border-white/5 py-3 px-4 overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-2.5 min-w-max">
        {categories.map((cat) => {
          const isActive = activeCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`px-4 py-1.5 rounded-lg text-xs md:text-sm font-semibold transition-all cursor-pointer select-none whitespace-nowrap ${
                isActive
                  ? 'bg-white text-black shadow-md'
                  : 'bg-white/10 text-zinc-300 hover:bg-white/15 hover:text-white'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>
    </div>
  );
};
