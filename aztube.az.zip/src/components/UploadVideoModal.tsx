import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  Film, 
  Image as ImageIcon, 
  Link, 
  Sparkles, 
  Check, 
  AlertCircle,
  Clock,
  Tv,
  LogIn
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { uploadVideo } from '../services/videoService';
import { readImageAsCompressedDataUrl, storeLocalVideoFile } from '../utils/fileHelpers';
import { CategoryFilter } from '../types';

interface UploadVideoModalProps {
  onClose: () => void;
  onSuccess: (videoId: string) => void;
}

const CATEGORIES: CategoryFilter[] = [
  'Musiqi',
  'Oyunlar',
  'Texnologiya',
  'Təhsil',
  'Əyləncə',
  'Xəbərlər',
  'Vloq',
  'Podkastlar',
  'İdman',
];

const PRESET_THUMBNAILS = [
  'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1280&q=80',
  'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1280&q=80',
  'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1280&q=80',
  'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1280&q=80',
  'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1280&q=80',
];

export const UploadVideoModal: React.FC<UploadVideoModalProps> = ({
  onClose,
  onSuccess,
}) => {
  const { user, channel, loginWithGoogle } = useAuth();

  const [uploadMode, setUploadMode] = useState<'gallery' | 'url'>('gallery');
  const [selectedVideoFile, setSelectedVideoFile] = useState<File | null>(null);
  const [videoUrlInput, setVideoUrlInput] = useState('');

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CategoryFilter>('Texnologiya');
  const [duration, setDuration] = useState('05:30');

  const [thumbnailUrl, setThumbnailUrl] = useState(PRESET_THUMBNAILS[0]);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);

  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const videoFileInputRef = useRef<HTMLInputElement>(null);
  const imageFileInputRef = useRef<HTMLInputElement>(null);

  // Handle Video file selection from device/gallery
  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      setErrorMsg('Zəhmət olmasa düzgün video faylı seçin (MP4, WebM, MOV və s.)');
      return;
    }

    setSelectedVideoFile(file);
    setErrorMsg(null);

    // Auto-populate title if empty
    if (!title) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      setTitle(cleanName);
    }

    // Try detecting duration from video element
    try {
      const tempVideo = document.createElement('video');
      tempVideo.preload = 'metadata';
      tempVideo.onloadedmetadata = () => {
        const totalSecs = Math.round(tempVideo.duration);
        if (!isNaN(totalSecs) && totalSecs > 0) {
          const mins = Math.floor(totalSecs / 60);
          const secs = totalSecs % 60;
          setDuration(`${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`);
        }
      };
      tempVideo.src = URL.createObjectURL(file);
    } catch {
      // Fallback
    }
  };

  // Handle Thumbnail image selection from device/gallery
  const handleThumbnailFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const compressedDataUrl = await readImageAsCompressedDataUrl(file, 1280, 720, 0.85);
      setThumbnailUrl(compressedDataUrl);
      setThumbnailPreview(compressedDataUrl);
    } catch (err: any) {
      setErrorMsg(err.message || 'Şəkil yüklənərkən xəta baş verdi');
    }
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !channel) {
      setErrorMsg('Video paylaşmaq üçün əvvəlcə daxil olmalısınız.');
      return;
    }

    if (!title.trim()) {
      setErrorMsg('Video başlığını qeyd edin.');
      return;
    }

    let finalVideoUrl = '';

    if (uploadMode === 'gallery') {
      if (!selectedVideoFile) {
        setErrorMsg('Zəhmət olmasa cihazınızdan video faylını seçin.');
        return;
      }
    } else {
      if (!videoUrlInput.trim()) {
        setErrorMsg('Zəhmət olmasa video linkini daxil edin.');
        return;
      }
      finalVideoUrl = videoUrlInput.trim();
    }

    setIsUploading(true);
    setErrorMsg(null);

    try {
      const generatedId = `vid_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      // Simulate smooth upload progress
      setUploadProgress(25);

      if (uploadMode === 'gallery' && selectedVideoFile) {
        // Store in IndexedDB and generate playable blob URL
        finalVideoUrl = await storeLocalVideoFile(generatedId, selectedVideoFile);
      }

      setUploadProgress(70);

      const createdId = await uploadVideo({
        id: generatedId,
        title: title.trim(),
        description: description.trim(),
        videoUrl: finalVideoUrl,
        thumbnailUrl: thumbnailPreview || thumbnailUrl,
        duration: duration || '04:30',
        channelId: channel.id || user.uid,
        channelName: channel.name || user.displayName || 'İstifadəçi Kanalı',
        channelAvatar: channel.avatar || user.photoURL || undefined,
        channelHandle: channel.handle || `@user_${user.uid.slice(0, 5)}`,
        category,
        views: 1,
        likes: 0,
        dislikes: 0,
        createdAt: new Date().toISOString(),
      });

      setUploadProgress(100);

      setTimeout(() => {
        setIsUploading(false);
        onSuccess(createdId);
        onClose();
      }, 500);
    } catch (err: any) {
      setIsUploading(false);
      setErrorMsg(err.message || 'Video yüklənərkən xəta baş verdi.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#1c1c1c] border border-white/10 rounded-3xl shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 text-red-500 flex items-center justify-center">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">Yeni Video Paylaş</h2>
              <p className="text-xs text-zinc-400">Öz kanalınızdan videoları dünyaya təqdim edin</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If user is not logged in, prompt Google sign-in */}
        {!user ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-3xl bg-red-600/10 text-red-500 mx-auto flex items-center justify-center shadow-inner">
              <Tv className="w-8 h-8" />
            </div>
            <div className="max-w-md mx-auto space-y-2">
              <h3 className="text-white font-bold text-lg">Kanal Açın və Video Yükləyin</h3>
              <p className="text-zinc-400 text-sm">
                AzTube-da hər bir istifadəçi dərhal öz kanalını aça və qalereyasından video paylaşa bilər. Bunun üçün Google hesabınızla daxil olun.
              </p>
            </div>
            <button
              onClick={() => loginWithGoogle()}
              className="inline-flex items-center gap-2.5 bg-white text-black hover:bg-zinc-200 px-6 py-3 rounded-full font-bold text-sm shadow-lg transition-all cursor-pointer"
            >
              <LogIn className="w-4 h-4 text-red-600" />
              <span>Google Hesabı ilə Giriş Et</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            {errorMsg && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center gap-2.5 text-red-400 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Video Source Switcher Tabs */}
            <div className="flex bg-black/40 p-1 rounded-2xl border border-white/5">
              <button
                type="button"
                onClick={() => setUploadMode('gallery')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  uploadMode === 'gallery'
                    ? 'bg-red-600 text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Qalereyadan / Cihazdan Fayl Seç</span>
              </button>
              <button
                type="button"
                onClick={() => setUploadMode('url')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  uploadMode === 'url'
                    ? 'bg-red-600 text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Link className="w-3.5 h-3.5" />
                <span>Video Linki / YouTube</span>
              </button>
            </div>

            {/* Mode 1: File Pick from Gallery */}
            {uploadMode === 'gallery' ? (
              <div className="space-y-2">
                <input
                  type="file"
                  ref={videoFileInputRef}
                  onChange={handleVideoFileChange}
                  accept="video/*"
                  className="hidden"
                />
                <div
                  onClick={() => videoFileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                    selectedVideoFile
                      ? 'border-emerald-500/50 bg-emerald-500/5'
                      : 'border-white/15 hover:border-red-500/50 hover:bg-white/5'
                  }`}
                >
                  <Upload className={`w-8 h-8 mx-auto mb-2 ${selectedVideoFile ? 'text-emerald-400' : 'text-zinc-400'}`} />
                  {selectedVideoFile ? (
                    <div>
                      <p className="text-white font-bold text-sm truncate">{selectedVideoFile.name}</p>
                      <p className="text-xs text-emerald-400 mt-1">
                        Seçildi • {(selectedVideoFile.size / (1024 * 1024)).toFixed(1)} MB
                      </p>
                    </div>
                  ) : (
                    <div>
                      <p className="text-white font-medium text-sm">Videonu seçmək üçün bura klikləyin</p>
                      <p className="text-xs text-zinc-500 mt-1">MP4, WebM, MOV formatları dəstəklənir</p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* Mode 2: Video URL */
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Video Linki (MP4 və ya YouTube)</label>
                <input
                  type="url"
                  value={videoUrlInput}
                  onChange={(e) => setVideoUrlInput(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=... və ya video.mp4 linki"
                  className="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors"
                />
              </div>
            )}

            {/* Title & Category Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2 space-y-1">
                <label className="text-xs font-bold text-zinc-300">Video Başlığı *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Məs: Yeni Bakı Səyahəti Vloqu"
                  className="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Kateqoriya</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as CategoryFilter)}
                  className="w-full bg-[#121212] border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors cursor-pointer"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300">Təsvir (Məlumat)</label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Video haqqında ətraflı məlumat, teqlər və ya qeydlər..."
                className="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors resize-none"
              />
            </div>

            {/* Thumbnail Selection */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-zinc-300">Önizləmə Şəkli (Thumbnail)</label>
                <input
                  type="file"
                  ref={imageFileInputRef}
                  onChange={handleThumbnailFileChange}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => imageFileInputRef.current?.click()}
                  className="text-xs text-red-400 hover:text-red-300 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Qalereyadan Şəkil Seç</span>
                </button>
              </div>

              {/* Thumbnails preview pills */}
              <div className="grid grid-cols-5 gap-2">
                {thumbnailPreview && (
                  <div className="relative aspect-video rounded-xl overflow-hidden border-2 border-red-500">
                    <img src={thumbnailPreview} alt="" className="w-full h-full object-cover" />
                    <span className="absolute top-1 left-1 bg-red-600 text-white text-[9px] font-bold px-1 rounded">Seçilib</span>
                  </div>
                )}
                {PRESET_THUMBNAILS.slice(0, thumbnailPreview ? 4 : 5).map((thumb, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setThumbnailUrl(thumb);
                      setThumbnailPreview(null);
                    }}
                    className={`relative aspect-video rounded-xl overflow-hidden border cursor-pointer transition-all ${
                      thumbnailUrl === thumb && !thumbnailPreview
                        ? 'border-red-500 ring-2 ring-red-500/50'
                        : 'border-white/10 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={thumb} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </div>

            {/* Upload Progress Bar */}
            {isUploading && (
              <div className="space-y-1.5 pt-2">
                <div className="flex justify-between text-xs text-zinc-400">
                  <span>Video hazırlanır və yüklənir...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-red-600 to-red-400 transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Footer Buttons */}
            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={onClose}
                disabled={isUploading}
                className="px-5 py-2.5 rounded-full text-sm font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Ləğv et
              </button>
              <button
                type="submit"
                disabled={isUploading}
                className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 text-white font-bold text-sm px-6 py-2.5 rounded-full shadow-lg shadow-red-600/30 transition-all cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isUploading ? 'Yüklənir...' : 'İndi Paylaş'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
