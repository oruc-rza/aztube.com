import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  CheckCircle2, 
  Tv, 
  Edit3, 
  Save, 
  Calendar, 
  Play, 
  Video as VideoIcon,
  Sparkles,
  Users
} from 'lucide-react';
import { Channel, Video } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
  toggleSubscription, 
  subscribeUserSubscriptions 
} from '../services/videoService';
import { VideoCard } from './VideoCard';

interface ChannelModalProps {
  channelId: string;
  allVideos: Video[];
  onClose: () => void;
  onSelectVideo: (video: Video) => void;
  onToggleWatchLater: (video: Video) => void;
  onDeleteVideo?: (videoId: string) => void;
}

export const ChannelModal: React.FC<ChannelModalProps> = ({
  channelId,
  allVideos,
  onClose,
  onSelectVideo,
  onToggleWatchLater,
  onDeleteVideo,
}) => {
  const { user, channel: authChannel, updateChannel, loginWithGoogle } = useAuth();
  const [activeTab, setActiveTab] = useState<'videos' | 'about'>('videos');
  const [isEditing, setIsEditing] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);

  const isOwner = user && user.uid === channelId;

  // Channel details
  const [channelData, setChannelData] = useState<Partial<Channel>>({
    name: 'Kanal',
    handle: '@kanal',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=1280&q=80',
    bio: 'AzTube video paylaşım platformasındakı rəsmi kanalım.',
    subscribersCount: 1,
  });

  // Filter videos belonging to this channel (memoized)
  const channelVideos = useMemo(
    () => allVideos.filter((v) => v.channelId === channelId),
    [allVideos, channelId]
  );

  const firstVid = channelVideos[0];

  // Sync channel data
  useEffect(() => {
    if (isOwner && authChannel) {
      setChannelData(authChannel);
    } else if (firstVid) {
      setChannelData({
        name: firstVid.channelName,
        handle: firstVid.channelHandle || `@${firstVid.channelName.toLowerCase().replace(/\s+/g, '')}`,
        avatar: firstVid.channelAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
        bannerUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=1280&q=80',
        bio: `${firstVid.channelName} kanalının bütün maraqlı videoları burada!`,
        subscribersCount: Math.max(1, Math.floor((firstVid.views || 10) / 10)),
      });
    }
  }, [channelId, isOwner, authChannel, firstVid?.channelName, firstVid?.channelAvatar, firstVid?.channelHandle]);

  // Subscription state
  useEffect(() => {
    if (!user) {
      setIsSubscribed(false);
      return;
    }
    const unsub = subscribeUserSubscriptions(user.uid, (ids) => {
      setIsSubscribed(ids.includes(channelId));
    });
    return () => {
      if (unsub) unsub();
    };
  }, [user, channelId]);

  const handleToggleSub = async () => {
    if (!user) {
      loginWithGoogle();
      return;
    }
    const next = !isSubscribed;
    setIsSubscribed(next);
    await toggleSubscription(user.uid, channelId, !next);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner && updateChannel) {
      await updateChannel({
        name: channelData.name,
        handle: channelData.handle,
        bio: channelData.bio,
      });
      setIsEditing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md overflow-y-auto">
      {/* Top sticky bar */}
      <div className="sticky top-0 z-50 bg-[#0f0f0f]/90 border-b border-white/10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Tv className="w-5 h-5 text-red-500" />
          <span className="text-white font-bold text-sm">
            {channelData.name} Kanalı
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-zinc-400 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="max-w-6xl mx-auto pb-12">
        {/* Banner */}
        <div className="relative h-44 sm:h-60 w-full overflow-hidden bg-zinc-900 border-b border-white/10">
          <img
            src={channelData.bannerUrl || 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=1280&q=80'}
            alt=""
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
        </div>

        {/* Channel Details Header */}
        <div className="px-4 sm:px-8 -mt-16 sm:-mt-20 relative z-10 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="flex items-end gap-4">
            <img
              src={channelData.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'}
              alt={channelData.name}
              className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-4 border-[#0f0f0f] shadow-2xl bg-zinc-800"
            />
            <div className="mb-2">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  {channelData.name}
                </h1>
                <CheckCircle2 className="w-5 h-5 text-blue-400" />
              </div>
              <p className="text-sm text-zinc-400">{channelData.handle}</p>
              <div className="flex items-center gap-2 text-xs text-zinc-500 mt-1">
                <span>{channelData.subscribersCount || 1} abunəçi</span>
                <span>•</span>
                <span>{channelVideos.length} video</span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="mb-2">
            {isOwner ? (
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-full transition-colors cursor-pointer"
              >
                <Edit3 className="w-4 h-4" />
                <span>{isEditing ? 'Ləğv et' : 'Kanalı Redaktə Et'}</span>
              </button>
            ) : (
              <button
                onClick={handleToggleSub}
                className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all cursor-pointer ${
                  isSubscribed
                    ? 'bg-white/10 text-zinc-300 hover:bg-white/20'
                    : 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-600/30'
                }`}
              >
                {isSubscribed ? 'Abunəsən' : 'Abunə Ol'}
              </button>
            )}
          </div>
        </div>

        {/* Edit Form Modal/Drawer if editing */}
        {isEditing && isOwner && (
          <form
            onSubmit={handleSaveProfile}
            className="mx-4 sm:mx-8 mt-6 p-5 bg-[#1c1c1c] border border-white/10 rounded-2xl space-y-4"
          >
            <h3 className="text-white font-bold text-sm">Kanal Məlumatlarını Yenilə</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-zinc-400">Kanalın Adı</label>
                <input
                  type="text"
                  value={channelData.name || ''}
                  onChange={(e) => setChannelData({ ...channelData, name: e.target.value })}
                  className="w-full bg-[#121212] border border-white/15 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-red-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-zinc-400">İstifadəçi Adı (Handle)</label>
                <input
                  type="text"
                  value={channelData.handle || ''}
                  onChange={(e) => setChannelData({ ...channelData, handle: e.target.value })}
                  className="w-full bg-[#121212] border border-white/15 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-red-500"
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-zinc-400">Haqqında (Bio)</label>
              <textarea
                rows={2}
                value={channelData.bio || ''}
                onChange={(e) => setChannelData({ ...channelData, bio: e.target.value })}
                className="w-full bg-[#121212] border border-white/15 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-red-500"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 rounded-full text-xs text-zinc-400 hover:text-white"
              >
                Ləğv et
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs px-5 py-2 rounded-full"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Yadda saxla</span>
              </button>
            </div>
          </form>
        )}

        {/* Tab Navigation */}
        <div className="px-4 sm:px-8 mt-8 border-b border-white/10 flex items-center gap-8">
          <button
            onClick={() => setActiveTab('videos')}
            className={`pb-3 text-sm font-bold transition-colors cursor-pointer border-b-2 ${
              activeTab === 'videos'
                ? 'border-red-500 text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            Videolar ({channelVideos.length})
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`pb-3 text-sm font-bold transition-colors cursor-pointer border-b-2 ${
              activeTab === 'about'
                ? 'border-red-500 text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            Haqqında
          </button>
        </div>

        {/* Content Tab: Videos */}
        {activeTab === 'videos' && (
          <div className="px-4 sm:px-8 mt-6">
            {channelVideos.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <VideoIcon className="w-12 h-12 text-zinc-600 mx-auto" />
                <p className="text-zinc-400 text-sm">Bu kanalda hələ video paylaşılmayıb.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {channelVideos.map((vid) => (
                  <VideoCard
                    key={vid.id}
                    video={vid}
                    onSelect={onSelectVideo}
                    onOpenChannel={() => {}}
                    onToggleWatchLater={onToggleWatchLater}
                    onDeleteVideo={onDeleteVideo}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Content Tab: About */}
        {activeTab === 'about' && (
          <div className="px-4 sm:px-8 mt-6 max-w-2xl space-y-4">
            <div className="p-5 bg-[#1c1c1c] rounded-2xl border border-white/10 space-y-3">
              <h3 className="text-white font-bold text-sm">Kanal Təsviri</h3>
              <p className="text-zinc-300 text-sm whitespace-pre-wrap leading-relaxed">
                {channelData.bio || 'Məlumat qeyd edilməyib.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
