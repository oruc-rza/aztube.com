import React, { useState, useEffect } from 'react';
import { 
  X, 
  ThumbsUp, 
  ThumbsDown, 
  Share2, 
  Clock, 
  Trash2, 
  CheckCircle2, 
  Send, 
  MessageSquare, 
  Play,
  Check,
  Tv,
  Eye
} from 'lucide-react';
import { Video, Comment } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
  incrementVideoViews, 
  toggleVideoReaction, 
  getUserReaction, 
  subscribeComments, 
  addComment, 
  deleteCommentById,
  toggleSubscription,
  subscribeUserSubscriptions
} from '../services/videoService';
import { getLocalVideoUrl } from '../utils/fileHelpers';

interface VideoPlayerModalProps {
  video: Video;
  allVideos: Video[];
  onClose: () => void;
  onSelectVideo: (video: Video) => void;
  onOpenChannel: (channelId: string) => void;
  onToggleWatchLater: (video: Video) => void;
  isWatchLater?: boolean;
  onDeleteVideo?: (videoId: string) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  video,
  allVideos,
  onClose,
  onSelectVideo,
  onOpenChannel,
  onToggleWatchLater,
  isWatchLater = false,
  onDeleteVideo,
}) => {
  const { user, loginWithGoogle } = useAuth();
  const [resolvedVideoUrl, setResolvedVideoUrl] = useState<string>(video.videoUrl);
  const [userReaction, setUserReaction] = useState<'like' | 'dislike' | null>(null);
  const [likesCount, setLikesCount] = useState<number>(video.likes || 0);
  const [dislikesCount, setDislikesCount] = useState<number>(video.dislikes || 0);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [showFullDesc, setShowFullDesc] = useState(false);

  const isOwner = user && user.uid === video.channelId;

  // Track view increment once on open (blocks owner views and duplicate session views)
  useEffect(() => {
    incrementVideoViews(video.id, video.channelId, user?.uid);
  }, [video.id, video.channelId, user?.uid]);

  // Check if video has an IndexedDB local video file stored
  useEffect(() => {
    let active = true;
    getLocalVideoUrl(video.id).then((localUrl) => {
      if (active && localUrl) {
        setResolvedVideoUrl(localUrl);
      } else if (active) {
        setResolvedVideoUrl(video.videoUrl);
      }
    });
    return () => {
      active = false;
    };
  }, [video.id, video.videoUrl]);

  // Sync likes state
  useEffect(() => {
    setLikesCount(video.likes || 0);
    setDislikesCount(video.dislikes || 0);
    if (user) {
      getUserReaction(video.id, user.uid).then((r) => setUserReaction(r));
    } else {
      setUserReaction(null);
    }
  }, [video.id, video.likes, video.dislikes, user?.uid]);

  // Listen to real-time comments
  useEffect(() => {
    const unsub = subscribeComments(video.id, (list) => {
      setComments(list);
    });
    return () => {
      if (unsub) unsub();
    };
  }, [video.id]);

  // Listen to user subscriptions
  useEffect(() => {
    if (!user) {
      setIsSubscribed(false);
      return;
    }
    const unsub = subscribeUserSubscriptions(user.uid, (channelIds) => {
      setIsSubscribed(channelIds.includes(video.channelId));
    });
    return () => {
      if (unsub) unsub();
    };
  }, [user, video.channelId]);

  // Helper to extract YouTube video ID if provided
  const getYouTubeEmbedUrl = (url: string) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return `https://www.youtube-nocookie.com/embed/${match[2]}?autoplay=1&rel=0&modestbranding=1`;
    }
    return null;
  };

  const ytEmbedUrl = getYouTubeEmbedUrl(resolvedVideoUrl);

  // Handle Like/Dislike
  const handleReaction = async (type: 'like' | 'dislike') => {
    if (!user) {
      loginWithGoogle();
      return;
    }

    const prevType = userReaction;
    const newType = userReaction === type ? null : type;

    // Optimistic UI
    setUserReaction(newType);
    if (type === 'like') {
      if (prevType === 'like') {
        setLikesCount((c) => Math.max(0, c - 1));
      } else if (prevType === 'dislike') {
        setLikesCount((c) => c + 1);
        setDislikesCount((c) => Math.max(0, c - 1));
      } else {
        setLikesCount((c) => c + 1);
      }
    } else if (type === 'dislike') {
      if (prevType === 'dislike') {
        setDislikesCount((c) => Math.max(0, c - 1));
      } else if (prevType === 'like') {
        setDislikesCount((c) => c + 1);
        setLikesCount((c) => Math.max(0, c - 1));
      } else {
        setDislikesCount((c) => c + 1);
      }
    }

    await toggleVideoReaction(video.id, user.uid, newType, prevType);
  };

  // Handle Subscription
  const handleToggleSub = async () => {
    if (!user) {
      loginWithGoogle();
      return;
    }
    const nextState = !isSubscribed;
    setIsSubscribed(nextState);
    await toggleSubscription(user.uid, video.channelId, !nextState);
  };

  // Handle Share
  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  // Handle Add Comment
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    if (!user) {
      loginWithGoogle();
      return;
    }

    setIsSubmittingComment(true);
    try {
      await addComment({
        videoId: video.id,
        userId: user.uid,
        userName: user.displayName || user.email?.split('@')[0] || 'İstifadəçi',
        userAvatar: user.photoURL || undefined,
        comment: newComment.trim(),
        createdAt: new Date().toISOString(),
      });
      setNewComment('');
    } finally {
      setIsSubmittingComment(false);
    }
  };

  // Format relative date
  const formatRelativeTime = (isoDate: string) => {
    try {
      const now = new Date();
      const past = new Date(isoDate);
      const diffMs = now.getTime() - past.getTime();
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffDays > 30) return `${Math.floor(diffDays / 30)} ay əvvəl`;
      if (diffDays > 0) return `${diffDays} gün əvvəl`;
      if (diffHours > 0) return `${diffHours} saat əvvəl`;
      if (diffMins > 0) return `${diffMins} dəqiqə əvvəl`;
      return 'Bayaq';
    } catch {
      return 'Bayaq';
    }
  };

  const recommendedVideos = allVideos.filter((v) => v.id !== video.id);

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md overflow-y-auto">
      {/* Top sticky bar */}
      <div className="sticky top-0 z-50 bg-[#0f0f0f]/90 border-b border-white/10 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-xs">
            <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
          </div>
          <span className="text-white font-bold text-sm hidden sm:inline truncate max-w-md">
            {video.title}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-zinc-400 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
          title="Bağla (Esc)"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="max-w-7xl mx-auto p-3 md:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Watch Column (Left 2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          {/* Player Container */}
          <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black shadow-2xl border border-white/10">
            {ytEmbedUrl ? (
              <iframe
                src={ytEmbedUrl}
                title={video.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            ) : (
              <video
                src={resolvedVideoUrl}
                controls
                autoPlay
                playsInline
                poster={video.thumbnailUrl}
                className="w-full h-full object-contain"
              >
                Sizin brauzeriniz video oxutmağı dəstəkləmir.
              </video>
            )}
          </div>

          {/* Video Title */}
          <h1 className="text-lg md:text-xl font-bold text-white leading-snug">
            {video.title}
          </h1>

          {/* Channel Row & Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-white/10">
            {/* Channel Info */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => onOpenChannel(video.channelId)}
                className="flex items-center gap-3 focus:outline-none group text-left"
              >
                <img
                  src={video.channelAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'}
                  alt={video.channelName}
                  className="w-11 h-11 rounded-full object-cover border border-white/20 group-hover:ring-2 group-hover:ring-red-500 transition-all"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-white font-bold text-sm md:text-base group-hover:text-red-400 transition-colors">
                      {video.channelName}
                    </span>
                    <CheckCircle2 className="w-4 h-4 text-blue-400" />
                  </div>
                  <span className="text-xs text-zinc-400">
                    {video.channelHandle || '@kanal'}
                  </span>
                </div>
              </button>

              {/* Subscribe Button */}
              {!isOwner && (
                <button
                  onClick={handleToggleSub}
                  className={`ml-2 px-4 py-2 rounded-full text-xs md:text-sm font-bold transition-all cursor-pointer ${
                    isSubscribed
                      ? 'bg-white/10 hover:bg-white/20 text-zinc-300'
                      : 'bg-white text-black hover:bg-zinc-200'
                  }`}
                >
                  {isSubscribed ? 'Abunəsən' : 'Abunə Ol'}
                </button>
              )}
            </div>

            {/* Actions (Like, Dislike, Share, Watch Later, Delete) */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Like / Dislike Pill */}
              <div className="flex items-center bg-white/10 rounded-full overflow-hidden">
                <button
                  onClick={() => handleReaction('like')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-xs md:text-sm font-semibold transition-colors hover:bg-white/10 cursor-pointer ${
                    userReaction === 'like' ? 'text-red-400 bg-white/15' : 'text-zinc-300'
                  }`}
                  title="Bəyəndim"
                >
                  <ThumbsUp className={`w-4 h-4 ${userReaction === 'like' ? 'fill-current' : ''}`} />
                  <span>{likesCount}</span>
                </button>
                <div className="w-px h-5 bg-white/20" />
                <button
                  onClick={() => handleReaction('dislike')}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs md:text-sm font-semibold transition-colors hover:bg-white/10 cursor-pointer ${
                    userReaction === 'dislike' ? 'text-red-400 bg-white/15' : 'text-zinc-300'
                  }`}
                  title="Bəyənmədim"
                >
                  <ThumbsDown className={`w-4 h-4 ${userReaction === 'dislike' ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Share button */}
              <button
                onClick={handleShare}
                className="flex items-center gap-2 bg-white/10 hover:bg-white/15 text-zinc-300 hover:text-white px-3.5 py-2 rounded-full text-xs md:text-sm font-semibold transition-colors cursor-pointer"
                title="Paylaş"
              >
                {copiedShare ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Kopyalandı!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4" />
                    <span>Paylaş</span>
                  </>
                )}
              </button>

              {/* Watch Later */}
              <button
                onClick={() => onToggleWatchLater(video)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-full text-xs md:text-sm font-semibold transition-colors cursor-pointer ${
                  isWatchLater
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-white/10 hover:bg-white/15 text-zinc-300 hover:text-white'
                }`}
                title="Sonra izlə"
              >
                <Clock className="w-4 h-4" />
                <span className="hidden sm:inline">{isWatchLater ? 'Yadda saxlanıldı' : 'Sonra izlə'}</span>
              </button>

              {/* Delete button (owner only) */}
              {isOwner && onDeleteVideo && (
                <button
                  onClick={() => {
                    if (confirm('Bu videonu tamamilə silmək istədiyinizdən əminsiniz?')) {
                      onDeleteVideo(video.id);
                      onClose();
                    }
                  }}
                  className="flex items-center gap-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 px-3 py-2 rounded-full text-xs font-semibold transition-colors cursor-pointer"
                  title="Videonu sil"
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Sil</span>
                </button>
              )}
            </div>
          </div>

          {/* Description Box */}
          <div className="bg-[#1c1c1c] rounded-2xl p-4 text-sm text-zinc-300">
            <div className="flex flex-wrap items-center gap-3 font-semibold text-white mb-2 text-xs md:text-sm">
              <span className="inline-flex items-center gap-1.5 font-bold text-white bg-white/5 px-2.5 py-1 rounded-lg border border-white/10">
                <Eye className="w-4 h-4 text-red-500" />
                <span>
                  {allVideos.find((v) => v.id === video.id)?.views !== undefined
                    ? `${allVideos.find((v) => v.id === video.id)!.views.toLocaleString()} baxış`
                    : video.views ? `${video.views.toLocaleString()} baxış` : '0 baxış'}
                </span>
              </span>
              <span>•</span>
              <span className="text-zinc-400">{formatRelativeTime(video.createdAt)}</span>
              <span>•</span>
              <span className="bg-red-500/20 text-red-400 text-xs px-2.5 py-1 rounded-md font-bold">
                {video.category}
              </span>
            </div>

            <p className={`whitespace-pre-wrap leading-relaxed ${!showFullDesc && 'line-clamp-3'}`}>
              {video.description || 'Bu video üçün təsvir qeyd edilməyib.'}
            </p>

            {video.description && video.description.length > 120 && (
              <button
                onClick={() => setShowFullDesc(!showFullDesc)}
                className="mt-2 text-xs font-bold text-white hover:underline cursor-pointer"
              >
                {showFullDesc ? 'Daha az göstər' : 'Daha çox göstər...'}
              </button>
            )}
          </div>

          {/* Comments Section */}
          <div className="pt-4 space-y-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-zinc-400" />
              <h3 className="text-white font-bold text-base md:text-lg">
                Rəylər ({comments.length})
              </h3>
            </div>

            {/* Comment Form */}
            {user ? (
              <form onSubmit={handleAddComment} className="flex gap-3">
                <img
                  src={user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                  alt=""
                  className="w-9 h-9 rounded-full object-cover shrink-0 border border-white/10"
                />
                <div className="flex-1 space-y-2">
                  <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Rəy əlavə edin..."
                    className="w-full bg-transparent border-b border-white/20 focus:border-red-500 text-white placeholder-zinc-500 text-sm py-1.5 focus:outline-none transition-colors"
                  />
                  {newComment.trim() && (
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setNewComment('')}
                        className="px-3 py-1.5 rounded-full text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
                      >
                        Ləğv et
                      </button>
                      <button
                        type="submit"
                        disabled={isSubmittingComment}
                        className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 text-white px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Rəy bildir</span>
                      </button>
                    </div>
                  )}
                </div>
              </form>
            ) : (
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs text-zinc-300">
                <span>Rəy bildirmək üçün Google ilə daxil olun.</span>
                <button
                  onClick={() => loginWithGoogle()}
                  className="text-red-400 hover:text-red-300 font-bold hover:underline cursor-pointer"
                >
                  Daxil ol
                </button>
              </div>
            )}

            {/* Comments List */}
            <div className="space-y-4 pt-2">
              {comments.length === 0 ? (
                <p className="text-xs text-zinc-500 py-4 text-center">
                  Hələ heç bir rəy yazılmayıb. İlk rəyi siz yazın!
                </p>
              ) : (
                comments.map((comm) => (
                  <div key={comm.id} className="flex gap-3 group">
                    <img
                      src={comm.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                      alt={comm.userName}
                      className="w-8 h-8 rounded-full object-cover shrink-0 border border-white/10"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-semibold text-xs">{comm.userName}</span>
                        <span className="text-[11px] text-zinc-500">{formatRelativeTime(comm.createdAt)}</span>
                      </div>
                      <p className="text-zinc-300 text-sm mt-0.5 leading-relaxed">{comm.comment}</p>
                    </div>

                    {user && user.uid === comm.userId && (
                      <button
                        onClick={() => deleteCommentById(comm.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 text-zinc-500 hover:text-red-400 transition-all cursor-pointer"
                        title="Rəyi sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Other Shared Videos Sidebar (Right 1 col) */}
        <div className="space-y-3">
          <h3 className="text-white font-bold text-sm tracking-wide">
            Digər paylaşılan videolar
          </h3>

          <div className="space-y-3">
            {recommendedVideos.length === 0 ? (
              <p className="text-xs text-zinc-500 py-6 text-center bg-white/5 rounded-xl border border-white/5">
                Hələ başqa paylaşılan video yoxdur.
              </p>
            ) : (
              recommendedVideos.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectVideo(item)}
                  className="group flex gap-2.5 p-1.5 rounded-xl hover:bg-white/5 transition-all cursor-pointer"
                >
                  {/* Thumb */}
                  <div className="relative w-36 aspect-video rounded-xl overflow-hidden shrink-0 bg-zinc-900 border border-white/5">
                    <img
                      src={item.thumbnailUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                    <span className="absolute bottom-1 right-1 bg-black/85 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                      {item.duration || '04:20'}
                    </span>
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-semibold text-xs line-clamp-2 leading-snug group-hover:text-red-400 transition-colors">
                      {item.title}
                    </h4>
                    <p className="text-zinc-400 text-[11px] truncate mt-1">
                      {item.channelName}
                    </p>
                    <p className="text-zinc-500 text-[10px] mt-0.5">
                      {item.views ? `${item.views.toLocaleString()} baxış` : '0 baxış'}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
