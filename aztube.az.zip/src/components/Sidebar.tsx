import React from 'react';
import { 
  Home, 
  Flame, 
  Tv, 
  Clock, 
  ThumbsUp, 
  Compass, 
  Music2, 
  Gamepad2, 
  Laptop, 
  GraduationCap, 
  Smile, 
  Newspaper, 
  Camera, 
  Mic, 
  Trophy,
  Video,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CategoryFilter } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onCloseMobile: () => void;
  selectedCategory: CategoryFilter;
  onSelectCategory: (cat: CategoryFilter) => void;
  onOpenWatchLater: () => void;
  onOpenMyChannel: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onCloseMobile,
  selectedCategory,
  onSelectCategory,
  onOpenWatchLater,
  onOpenMyChannel,
}) => {
  const { user, channel } = useAuth();

  const categories: { label: CategoryFilter; icon: React.ReactNode }[] = [
    { label: 'Hamısı', icon: <Compass className="w-4 h-4" /> },
    { label: 'Musiqi', icon: <Music2 className="w-4 h-4 text-pink-400" /> },
    { label: 'Oyunlar', icon: <Gamepad2 className="w-4 h-4 text-emerald-400" /> },
    { label: 'Texnologiya', icon: <Laptop className="w-4 h-4 text-cyan-400" /> },
    { label: 'Təhsil', icon: <GraduationCap className="w-4 h-4 text-amber-400" /> },
    { label: 'Əyləncə', icon: <Smile className="w-4 h-4 text-yellow-400" /> },
    { label: 'Xəbərlər', icon: <Newspaper className="w-4 h-4 text-blue-400" /> },
    { label: 'Vloq', icon: <Camera className="w-4 h-4 text-purple-400" /> },
    { label: 'Podkastlar', icon: <Mic className="w-4 h-4 text-orange-400" /> },
    { label: 'İdman', icon: <Trophy className="w-4 h-4 text-green-400" /> },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/60 z-30 md:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      {/* Sidebar Drawer */}
      <aside
        className={`fixed md:sticky top-[57px] left-0 h-[calc(100vh-57px)] bg-[#0f0f0f] border-r border-white/10 overflow-y-auto z-30 transition-all duration-300 ${
          isOpen ? 'w-60 translate-x-0' : '-translate-x-full md:translate-x-0 md:w-20'
        }`}
      >
        <div className="p-3 space-y-6">
          {/* Main Navigation */}
          <div className="space-y-1">
            <button
              onClick={() => {
                onSelectCategory('Hamısı');
                onCloseMobile();
              }}
              className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                selectedCategory === 'Hamısı'
                  ? 'bg-white/15 text-white font-semibold'
                  : 'text-zinc-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Home className="w-5 h-5 shrink-0" />
              {isOpen && <span>Əsas səhifə</span>}
            </button>

            <button
              onClick={() => {
                onSelectCategory('Trendlər');
                onCloseMobile();
              }}
              className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                selectedCategory === 'Trendlər'
                  ? 'bg-red-500/20 text-red-400 font-semibold'
                  : 'text-zinc-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Flame className="w-5 h-5 shrink-0 text-red-500" />
              {isOpen && <span>Trendlər</span>}
            </button>
          </div>

          <div className="border-t border-white/10" />

          {/* User Library Section */}
          <div className="space-y-1">
            {isOpen && (
              <p className="px-3 text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                Kitabxana
              </p>
            )}

            <button
              onClick={() => {
                onOpenWatchLater();
                onCloseMobile();
              }}
              className="w-full flex items-center gap-4 px-3 py-2.5 rounded-xl text-sm font-medium text-zinc-300 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            >
              <Clock className="w-5 h-5 shrink-0 text-amber-400" />
              {isOpen && <span>Sonra izlə</span>}
            </button>

            {user && (
              <button
                onClick={() => {
                  onOpenMyChannel();
                  onCloseMobile();
                }}
                className="w-full flex items-center gap-4 px-3 py-2.5 rounded-xl text-sm font-medium text-zinc-300 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
              >
                <Tv className="w-5 h-5 shrink-0 text-red-400" />
                {isOpen && <span>Kanalım</span>}
              </button>
            )}
          </div>

          <div className="border-t border-white/10" />

          {/* Categories Explorer */}
          <div className="space-y-1">
            {isOpen && (
              <p className="px-3 text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                Kateqoriyalar
              </p>
            )}

            {categories.slice(1).map((cat) => (
              <button
                key={cat.label}
                onClick={() => {
                  onSelectCategory(cat.label);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-4 px-3 py-2 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  selectedCategory === cat.label
                    ? 'bg-red-500/20 text-red-400 font-semibold'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
                title={cat.label}
              >
                <span className="shrink-0">{cat.icon}</span>
                {isOpen && <span>{cat.label}</span>}
              </button>
            ))}
          </div>

          {isOpen && (
            <div className="border-t border-white/10 pt-4 px-3 text-[11px] text-zinc-500 space-y-2">
              <p>© 2026 AzTube</p>
              <p>Azərbaycanın azad və açıq video paylaşım şəbəkəsi.</p>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
