import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  MoreVertical, 
  Clock, 
  Share2, 
  Trash2, 
  CheckCircle2,
  Tv,
  Eye
} from 'lucide-react';
import { Video } from '../types';
import { useAuth } from '../context/AuthContext';

interface VideoCardProps {
  video: Video;
  onSelect: (video: Video) => void;
  onOpenChannel: (channelId: string) => void;
  onToggleWatchLater: (video: Video) => void;
  isWatchLater?: boolean;
  onDeleteVideo?: (videoId: string) => void;
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  onSelect,
  onOpenChannel,
  onToggleWatchLater,
  isWatchLater = false,
  onDeleteVideo,
}) => {
  const { user } = useAuth();
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const isOwner = user && user.uid === video.channelId;

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Format views
  const formatViews = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M baxış`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K baxış`;
    return `${count} baxış`;
  };

  // Format relative date
  const formatRelativeTime = (isoDate: string) => {
    try {
      const now = new Date();
      const past = new Date(isoDate);
      const diffMs = now.getTime() - past.getTime();
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffDays > 30) return `${Math.floor(diffDays / 30)} ay əvvəl`;
      if (diffDays > 0) return `${diffDays} gün əvvəl`;
      if (diffHours > 0) return `${diffHours} saat əvvəl`;
      if (diffMins > 0) return `${diffMins} dəqiqə əvvəl`;
      return 'Bayaq';
    } catch {
      return 'Bayaq';
    }
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowMenu(false);
    navigator.clipboard?.writeText(window.location.origin);
    // Simple alert or toast feedback can be provided
  };

  return (
    <div className="group flex flex-col gap-3 cursor-pointer">
      {/* Thumbnail Area */}
      <div 
        onClick={() => onSelect(video)}
        className="relative aspect-video w-full rounded-2xl overflow-hidden bg-zinc-900 border border-white/5 group-hover:border-white/20 transition-all shadow-md group-hover:shadow-red-950/20"
      >
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />

        {/* Play hover overlay */}
        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
            <Play className="w-6 h-6 fill-current ml-0.5" />
          </div>
        </div>

        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-black/85 text-white text-[11px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
          {video.duration || '05:00'}
        </div>

        {/* Category tag */}
        <div className="absolute top-2 left-2 bg-black/70 text-zinc-300 text-[10px] font-semibold px-2 py-0.5 rounded-md backdrop-blur-xs uppercase tracking-wider">
          {video.category}
        </div>
      </div>

      {/* Info Row */}
      <div className="flex gap-3 px-0.5">
        {/* Channel Avatar */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onOpenChannel(video.channelId);
          }}
          className="shrink-0 mt-0.5 focus:outline-none"
          title={video.channelName}
        >
          <img
            src={video.channelAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
            alt={video.channelName}
            className="w-9 h-9 rounded-full object-cover hover:ring-2 hover:ring-red-500 transition-all border border-white/10"
          />
        </button>

        {/* Meta texts */}
        <div className="flex-1 min-w-0" onClick={() => onSelect(video)}>
          <h3 
            className="text-white font-semibold text-sm leading-snug line-clamp-2 group-hover:text-red-400 transition-colors"
            title={video.title}
          >
            {video.title}
          </h3>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenChannel(video.channelId);
            }}
            className="flex items-center gap-1 text-xs text-zinc-400 hover:text-white transition-colors mt-1 truncate"
          >
            <span className="truncate">{video.channelName}</span>
            <CheckCircle2 className="w-3 h-3 text-blue-400 shrink-0" />
          </button>

          <div className="flex items-center gap-2 text-xs text-zinc-400 mt-1">
            <span className="inline-flex items-center gap-1 font-bold text-zinc-300 bg-white/5 hover:bg-white/10 px-2 py-0.5 rounded-md border border-white/10 transition-colors">
              <Eye className="w-3.5 h-3.5 text-red-500" />
              <span>{formatViews(video.views)}</span>
            </span>
            <span>•</span>
            <span className="text-zinc-500">{formatRelativeTime(video.createdAt)}</span>
          </div>
        </div>

        {/* 3-dots Context Menu */}
        <div className="relative shrink-0" ref={menuRef}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="p-1 text-zinc-400 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            title="Daha çox"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMenu && (
            <div className="absolute right-0 mt-1 w-48 bg-[#1c1c1c] border border-white/10 rounded-xl shadow-2xl p-1.5 z-40 text-xs">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMenu(false);
                  onToggleWatchLater(video);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-zinc-300 hover:text-white hover:bg-white/10 text-left transition-colors cursor-pointer"
              >
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>{isWatchLater ? 'Siyahıdan çıxar' : 'Sonra izlə'}</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMenu(false);
                  onOpenChannel(video.channelId);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-zinc-300 hover:text-white hover:bg-white/10 text-left transition-colors cursor-pointer"
              >
                <Tv className="w-3.5 h-3.5 text-blue-400" />
                <span>Kanala keç</span>
              </button>

              <button
                onClick={handleShare}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-zinc-300 hover:text-white hover:bg-white/10 text-left transition-colors cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Paylaş</span>
              </button>

              {isOwner && onDeleteVideo && (
                <>
                  <div className="border-t border-white/10 my-1" />
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowMenu(false);
                      if (confirm('Bu videonu silmək istədiyinizdən əminsiniz?')) {
                        onDeleteVideo(video.id);
                      }
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-red-400 hover:bg-red-500/15 text-left transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Videonu sil</span>
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
