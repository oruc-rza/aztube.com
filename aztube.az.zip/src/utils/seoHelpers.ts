import { Video } from '../types';

const DEFAULT_TITLE = 'AzTube - Azərbaycanın Açıq Video Paylaşım Platforması';
const DEFAULT_DESCRIPTION = 'AzTube ilə hər kəs öz kanalını aça, qalereyasından video yükləyə və minlərlə maraqlı videonu real vaxtda izləyə bilər.';

function setOrCreateMetaTag(attrName: 'name' | 'property', attrValue: string, content: string) {
  let element = document.querySelector(`meta[${attrName}="${attrValue}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attrName, attrValue);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
}

export function updatePageMetadataForVideo(video: Video | null) {
  if (!video) {
    document.title = DEFAULT_TITLE;
    setOrCreateMetaTag('name', 'description', DEFAULT_DESCRIPTION);
    setOrCreateMetaTag('property', 'og:title', DEFAULT_TITLE);
    setOrCreateMetaTag('property', 'og:description', DEFAULT_DESCRIPTION);
    setOrCreateMetaTag('property', 'og:type', 'website');
    setOrCreateMetaTag('name', 'twitter:title', DEFAULT_TITLE);
    setOrCreateMetaTag('name', 'twitter:description', DEFAULT_DESCRIPTION);

    const ldJsonScript = document.getElementById('video-structured-data');
    if (ldJsonScript) {
      ldJsonScript.remove();
    }
    return;
  }

  const pageTitle = `${video.title} - ${video.channelName} | AzTube`;
  const cleanDescription = video.description
    ? `${video.description.slice(0, 160)}... AzTube-da izləyin.`
    : `${video.channelName} kanalının təqdim etdiyi "${video.title}" videosunu AzTube-da yüksək keyfiyyətlə izləyin.`;

  const shareImageUrl = video.thumbnailUrl;
  const currentUrl = window.location.href;

  document.title = pageTitle;
  setOrCreateMetaTag('name', 'description', cleanDescription);
  setOrCreateMetaTag('property', 'og:title', pageTitle);
  setOrCreateMetaTag('property', 'og:description', cleanDescription);
  setOrCreateMetaTag('property', 'og:type', 'video.other');
  setOrCreateMetaTag('property', 'og:url', currentUrl);
  setOrCreateMetaTag('property', 'og:site_name', 'AzTube');
  if (shareImageUrl) {
    setOrCreateMetaTag('property', 'og:image', shareImageUrl);
    setOrCreateMetaTag('property', 'og:image:alt', video.title);
  }

  setOrCreateMetaTag('name', 'twitter:card', 'summary_large_image');
  setOrCreateMetaTag('name', 'twitter:title', pageTitle);
  setOrCreateMetaTag('name', 'twitter:description', cleanDescription);
  if (shareImageUrl) {
    setOrCreateMetaTag('name', 'twitter:image', shareImageUrl);
  }

  // Schema.org VideoObject JSON-LD
  let ldJsonScript = document.getElementById('video-structured-data') as HTMLScriptElement | null;
  if (!ldJsonScript) {
    ldJsonScript = document.createElement('script');
    ldJsonScript.id = 'video-structured-data';
    ldJsonScript.type = 'application/ld+json';
    document.head.appendChild(ldJsonScript);
  }

  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'VideoObject',
    'name': video.title,
    'description': cleanDescription,
    'thumbnailUrl': [video.thumbnailUrl],
    'uploadDate': video.createdAt,
    'duration': video.duration,
    'interactionStatistic': {
      '@type': 'InteractionCounter',
      'interactionType': { '@type': 'WatchAction' },
      'userInteractionCount': video.views || 0,
    },
    'author': {
      '@type': 'Person',
      'name': video.channelName,
    },
  };

  ldJsonScript.textContent = JSON.stringify(schemaData);
}
