import React, { useState, useEffect, useMemo } from 'react';
import { 
  Play, 
  Flame, 
  Video as VideoIcon, 
  Search, 
  Plus, 
  Sparkles, 
  Tv, 
  Film,
  Compass
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Video, CategoryFilter, WatchLaterItem } from './types';
import { 
  fetchVideos, 
  subscribeVideos, 
  deleteVideoById, 
  subscribeWatchLater, 
  toggleWatchLater 
} from './services/videoService';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { CategoryBar } from './components/CategoryBar';
import { VideoCard } from './components/VideoCard';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { UploadVideoModal } from './components/UploadVideoModal';
import { ChannelModal } from './components/ChannelModal';
import { WatchLaterModal } from './components/WatchLaterModal';
import { updatePageMetadataForVideo } from './utils/seoHelpers';

const CATEGORIES: CategoryFilter[] = [
  'Hamısı',
  'Musiqi',
  'Oyunlar',
  'Texnologiya',
  'Təhsil',
  'Əyləncə',
  'Xəbərlər',
  'Vloq',
  'Podkastlar',
  'İdman',
  'Trendlər',
];

function MainApp() {
  const { user, channel, loginWithGoogle } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('Hamısı');

  // Modals state
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null);
  const [watchLaterOpen, setWatchLaterOpen] = useState(false);

  // Watch Later items
  const [watchLaterItems, setWatchLaterItems] = useState<WatchLaterItem[]>([]);

  // Subscribe to real-time videos
  useEffect(() => {
    const unsub = subscribeVideos((list) => {
      setVideos(list || []);
      setLoading(false);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  // Subscribe to Watch Later for logged in user
  useEffect(() => {
    if (!user?.uid) {
      setWatchLaterItems((prev) => (prev.length === 0 ? prev : []));
      return;
    }
    const unsub = subscribeWatchLater(user.uid, (items) => {
      setWatchLaterItems(items);
    });
    return () => {
      if (unsub) unsub();
    };
  }, [user?.uid]);

  // Update dynamic SEO & social sharing tags when video changes
  useEffect(() => {
    updatePageMetadataForVideo(activeVideo);
  }, [activeVideo]);

  // Toggle Watch Later
  const handleToggleWatchLater = async (video: Video) => {
    if (!user) {
      loginWithGoogle();
      return;
    }
    const isSaved = watchLaterItems.some((w) => w.videoId === video.id);
    await toggleWatchLater(user.uid, video, isSaved);
  };

  const isVideoInWatchLater = (videoId: string) => {
    return watchLaterItems.some((w) => w.videoId === videoId);
  };

  // Delete Video
  const handleDeleteVideo = async (videoId: string) => {
    await deleteVideoById(videoId);
    if (activeVideo && activeVideo.id === videoId) {
      setActiveVideo(null);
    }
  };

  // Filter & Search videos
  const filteredVideos = useMemo(() => {
    return videos.filter((v) => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = v.title.toLowerCase().includes(q);
        const matchesDesc = v.description?.toLowerCase().includes(q);
        const matchesChannel = v.channelName.toLowerCase().includes(q);
        const matchesCategory = v.category.toLowerCase().includes(q);
        if (!matchesTitle && !matchesDesc && !matchesChannel && !matchesCategory) {
          return false;
        }
      }

      // Category / Trends
      if (selectedCategory === 'Trendlər') {
        return (v.views || 0) >= 500;
      } else if (selectedCategory !== 'Hamısı') {
        return v.category === selectedCategory;
      }

      return true;
    });
  }, [videos, searchQuery, selectedCategory]);

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-zinc-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-red-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
        onOpenUpload={() => setUploadOpen(true)}
        onOpenChannel={(cId) => setActiveChannelId(cId)}
        onOpenWatchLater={() => setWatchLaterOpen(true)}
      />

      {/* Main Container */}
      <div className="flex flex-1">
        {/* Left Sidebar */}
        <Sidebar
          isOpen={sidebarOpen}
          onCloseMobile={() => setSidebarOpen(false)}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => setSelectedCategory(cat)}
          onOpenWatchLater={() => setWatchLaterOpen(true)}
          onOpenMyChannel={() => {
            if (user) {
              setActiveChannelId(user.uid);
            } else {
              loginWithGoogle();
            }
          }}
        />

        {/* Content Area */}
        <main className="flex-1 min-w-0 flex flex-col">
          {/* Horizontal Category Strip */}
          <CategoryBar
            categories={CATEGORIES}
            activeCategory={selectedCategory}
            onSelectCategory={(cat) => setSelectedCategory(cat)}
          />

          <div className="p-4 sm:p-6 lg:p-8 flex-1 space-y-6">
            {/* Creator Welcome Hero Card (if no search query) */}
            {!searchQuery && selectedCategory === 'Hamısı' && (
              <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-red-950/60 via-[#1a1215] to-[#121212] border border-red-500/20 p-6 sm:p-8 shadow-xl">
                <div className="relative z-10 max-w-2xl space-y-3">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 text-red-400 text-xs font-bold border border-red-500/30">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Azərbaycanın Açıq Video Paylaşım Şəbəkəsi</span>
                  </div>
                  <h2 className="text-xl sm:text-3xl font-black text-white tracking-tight leading-tight">
                    Hər kəs kanal aça və qalereyasından video paylaşa bilər!
                  </h2>
                  <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed">
                    Google hesabınızla daxil olaraq dərhal öz kanalınızı yaradın, telefon və ya kompüterinizdən videoları birbaşa yükləyin və hər kəsin videolarını real vaxtda izləyin.
                  </p>
                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => setUploadOpen(true)}
                      className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-full shadow-lg shadow-red-600/30 transition-all cursor-pointer active:scale-95"
                    >
                      <Plus className="w-4 h-4" />
                      <span>İndi Video Paylaş</span>
                    </button>
                    {!user && (
                      <button
                        onClick={() => loginWithGoogle()}
                        className="bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm px-5 py-2.5 rounded-full transition-colors cursor-pointer"
                      >
                        Google ilə Kanal Aç
                      </button>
                    )}
                  </div>
                </div>

                {/* Subtle background glow */}
                <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-red-600/10 to-transparent pointer-events-none" />
              </div>
            )}

            {/* Video Feed Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-5 bg-red-600 rounded-full" />
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {searchQuery ? `"${searchQuery}" axtarış nəticələri` : selectedCategory === 'Hamısı' ? 'Paylaşılan Videolar' : `${selectedCategory} Videoları`}
                </h2>
                <span className="text-xs text-zinc-500 font-medium">
                  ({filteredVideos.length})
                </span>
              </div>
            </div>

            {/* Video Cards Grid */}
            {loading ? (
              <div className="py-20 text-center space-y-3">
                <div className="w-10 h-10 border-2 border-red-500 border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs text-zinc-500">Videolar yüklənir...</p>
              </div>
            ) : filteredVideos.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8">
                {filteredVideos.map((video) => (
                  <VideoCard
                    key={video.id}
                    video={video}
                    onSelect={(v) => setActiveVideo(v)}
                    onOpenChannel={(cId) => setActiveChannelId(cId)}
                    onToggleWatchLater={handleToggleWatchLater}
                    isWatchLater={isVideoInWatchLater(video.id)}
                    onDeleteVideo={handleDeleteVideo}
                  />
                ))}
              </div>
            ) : (
              <div className="py-20 text-center space-y-4 max-w-md mx-auto">
                <div className="w-16 h-16 rounded-full bg-red-600/10 flex items-center justify-center mx-auto text-red-500">
                  <VideoIcon className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Hələ heç bir video paylaşılmayıb</h3>
                  <p className="text-zinc-400 text-xs mt-1 leading-relaxed">
                    {searchQuery
                      ? 'Axtarışınıza uyğun heç bir video aşkar edilmədi.'
                      : 'Saytda yalnız real istifadəçilərin paylaşdığı videolar nümayiş olunur. Qalereyanızdan və ya linklə ilk videonu dərhal paylaşın!'}
                  </p>
                </div>
                {searchQuery ? (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('Hamısı');
                    }}
                    className="px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Bütün Videolara Qayıt
                  </button>
                ) : (
                  <button
                    onClick={() => setUploadOpen(true)}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 text-white text-xs font-bold shadow-lg shadow-red-600/30 transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>İlk Videonu Paylaş</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Video Player Watch Modal */}
      {activeVideo && (
        <VideoPlayerModal
          video={activeVideo}
          allVideos={videos}
          onClose={() => setActiveVideo(null)}
          onSelectVideo={(v) => setActiveVideo(v)}
          onOpenChannel={(cId) => setActiveChannelId(cId)}
          onToggleWatchLater={handleToggleWatchLater}
          isWatchLater={isVideoInWatchLater(activeVideo.id)}
          onDeleteVideo={handleDeleteVideo}
        />
      )}

      {/* Upload Video Modal */}
      {uploadOpen && (
        <UploadVideoModal
          onClose={() => setUploadOpen(false)}
          onSuccess={(newVideoId) => {
            const uploaded = videos.find((v) => v.id === newVideoId);
            if (uploaded) {
              setActiveVideo(uploaded);
            }
          }}
        />
      )}

      {/* Channel Profile Modal */}
      {activeChannelId && (
        <ChannelModal
          channelId={activeChannelId}
          allVideos={videos}
          onClose={() => setActiveChannelId(null)}
          onSelectVideo={(v) => setActiveVideo(v)}
          onToggleWatchLater={handleToggleWatchLater}
          onDeleteVideo={handleDeleteVideo}
        />
      )}

      {/* Watch Later Modal */}
      {watchLaterOpen && (
        <WatchLaterModal
          items={watchLaterItems}
          allVideos={videos}
          onClose={() => setWatchLaterOpen(false)}
          onSelectVideo={(v) => setActiveVideo(v)}
          onRemoveItem={handleToggleWatchLater}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
