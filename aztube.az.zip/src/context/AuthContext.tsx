import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as fbSignOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { auth } from '../firebase';
import { Channel } from '../types';
import { getOrCreateChannel, updateChannelProfile } from '../services/videoService';

interface AuthContextType {
  user: User | null;
  channel: Channel | null;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateChannel: (data: Partial<Channel>) => Promise<void>;
  refreshChannel: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  channel: null,
  loading: true,
  loginWithGoogle: async () => {},
  logout: async () => {},
  updateChannel: async () => {},
  refreshChannel: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [channel, setChannel] = useState<Channel | null>(null);
  const [loading, setLoading] = useState(true);

  const loadChannelForUser = async (u: User) => {
    try {
      const ch = await getOrCreateChannel(
        u.uid,
        u.displayName || u.email?.split('@')[0] || 'Kanalım',
        u.photoURL || undefined,
        u.email || undefined
      );
      setChannel(ch);

      // Sync user to Cloud SQL users table
      const token = await u.getIdToken();
      fetch('/api/users/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: u.displayName,
          photoUrl: u.photoURL,
          channelHandle: ch.handle,
        }),
      }).catch(() => {});
    } catch (e) {
      console.warn('Channel load error:', e);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        await loadChannelForUser(currentUser);
      } else {
        setChannel(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        await loadChannelForUser(result.user);
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await fbSignOut(auth);
      setChannel(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const updateChannel = async (data: Partial<Channel>) => {
    if (!user) return;
    await updateChannelProfile(user.uid, data);
    setChannel((prev) => (prev ? { ...prev, ...data } : null));
  };

  const refreshChannel = async () => {
    if (user) {
      await loadChannelForUser(user);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        channel,
        loading,
        loginWithGoogle,
        logout,
        updateChannel,
        refreshChannel,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
