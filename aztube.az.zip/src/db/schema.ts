import { relations } from 'drizzle-orm';
import { boolean, doublePrecision, integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  name: text('name'),
  photoUrl: text('photo_url'),
  role: text('role').default('user').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Channels table (YouTube channel for user)
export const channels = pgTable('channels', {
  id: text('id').primaryKey(), // Firebase Auth UID
  name: text('name').notNull(),
  handle: text('handle').notNull(),
  avatar: text('avatar'),
  bannerUrl: text('banner_url'),
  bio: text('bio'),
  subscribersCount: integer('subscribers_count').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Videos table (YouTube-style user videos)
export const videos = pgTable('videos', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description').default('').notNull(),
  videoUrl: text('video_url').notNull(),
  thumbnailUrl: text('thumbnail_url').notNull(),
  duration: text('duration').default('00:00').notNull(),
  channelId: text('channel_id').notNull(),
  channelName: text('channel_name').notNull(),
  channelAvatar: text('channel_avatar'),
  channelHandle: text('channel_handle'),
  category: text('category').default('Ümumi').notNull(),
  views: integer('views').default(0).notNull(),
  likes: integer('likes').default(0).notNull(),
  dislikes: integer('dislikes').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Comments table
export const comments = pgTable('comments', {
  id: text('id').primaryKey(),
  movieId: text('movie_id').notNull(), // kept for compatibility with existing comments table
  userId: text('user_id').notNull(),
  userName: text('user_name').notNull(),
  userAvatar: text('user_avatar'),
  comment: text('comment').notNull(),
  rating: integer('rating'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Subscriptions table
export const subscriptions = pgTable('subscriptions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  channelId: text('channel_id').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Watch Later table
export const watchLater = pgTable('watch_later', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  videoId: text('video_id').notNull(),
  videoTitle: text('video_title').notNull(),
  thumbnailUrl: text('thumbnail_url').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Legacy movies table
export const movies = pgTable('movies', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  originalTitle: text('original_title').notNull(),
  description: text('description').notNull(),
  posterUrl: text('poster_url').notNull(),
  backdropUrl: text('backdrop_url'),
  videoUrl: text('video_url').notNull(),
  trailerUrl: text('trailer_url'),
  genres: text('genres').array().notNull(),
  year: integer('year').notNull(),
  imdbScore: doublePrecision('imdb_score').notNull(),
  quality: text('quality').notNull(),
  audio: text('audio').notNull(),
  category: text('category').notNull(),
  duration: text('duration'),
  director: text('director'),
  cast: text('cast'),
  addedDaysAgo: integer('added_days_ago').default(0).notNull(),
  isFeatured: boolean('is_featured').default(false).notNull(),
  isUpcoming: boolean('is_upcoming').default(false).notNull(),
  releaseDate: text('release_date'),
  views: integer('views').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Legacy watchlists table
export const watchlists = pgTable('watchlists', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  movieId: text('movie_id').notNull(),
  movieTitle: text('movie_title').notNull(),
  posterUrl: text('poster_url').notNull(),
  addedAt: timestamp('added_at').defaultNow(),
});
