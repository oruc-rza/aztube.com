import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  updateDoc,
  increment,
  query,
  where,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Video, Channel, Comment, WatchLaterItem } from '../types';

const VIDEOS_COL = 'videos';
const CHANNELS_COL = 'channels';
const COMMENTS_COL = 'comments';
const SUBS_COL = 'subscriptions';
const LIKES_COL = 'videoLikes';
const WATCH_LATER_COL = 'watchLater';

// Videos - Only user-uploaded videos from Firestore/database
export async function fetchVideos(): Promise<Video[]> {
  try {
    const snap = await getDocs(collection(db, VIDEOS_COL));
    const list: Video[] = [];
    snap.forEach((d) => {
      list.push({ ...(d.data() as Video), id: d.id });
    });
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  } catch (err) {
    console.warn('Firestore fetch videos error:', err);
    return [];
  }
}

export function subscribeVideos(callback: (videos: Video[]) => void) {
  try {
    const q = collection(db, VIDEOS_COL);
    return onSnapshot(
      q,
      (snapshot) => {
        const list: Video[] = [];
        snapshot.forEach((d) => {
          list.push({ ...(d.data() as Video), id: d.id });
        });
        // Sort by createdAt descending
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        callback(list);
      },
      (error) => {
        console.warn('Videos listener error:', error);
        callback([]);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, VIDEOS_COL);
  }
}

export async function uploadVideo(video: Omit<Video, 'id'> & { id?: string }): Promise<string> {
  const videoId = video.id || `vid_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const cleanData: Video = {
    id: videoId,
    title: video.title.trim(),
    description: video.description || '',
    videoUrl: video.videoUrl,
    thumbnailUrl: video.thumbnailUrl || 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1280&q=80',
    duration: video.duration || '05:00',
    channelId: video.channelId,
    channelName: video.channelName || 'İstifadəçi Kanalı',
    channelAvatar: video.channelAvatar || '',
    channelHandle: video.channelHandle || `@user_${video.channelId.substring(0, 6)}`,
    category: video.category || 'Ümumi',
    views: video.views || 0,
    likes: video.likes || 0,
    dislikes: video.dislikes || 0,
    createdAt: video.createdAt || new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, VIDEOS_COL, videoId), cleanData);

    // Also sync to Cloud SQL backend
    fetch('/api/videos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cleanData),
    }).catch(() => {});

    return videoId;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${VIDEOS_COL}/${videoId}`);
    return videoId;
  }
}

export async function deleteVideoById(videoId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, VIDEOS_COL, videoId));
    fetch(`/api/videos/${videoId}`, { method: 'DELETE' }).catch(() => {});
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${VIDEOS_COL}/${videoId}`);
  }
}

export async function incrementVideoViews(
  videoId: string,
  videoOwnerId: string,
  currentUserId?: string | null
): Promise<boolean> {
  // 1. Videonu paylaşan müəllif öz videosuna baxdıqda baxış sayı ARTMAYACAQ
  if (currentUserId && currentUserId === videoOwnerId) {
    return false;
  }

  // 2. Eyni brauzer sessiyasında təkrar-təkrar basıldıqda süni artımın qarşısı alınır
  const sessionKey = `aztube_viewed_${videoId}`;
  if (sessionStorage.getItem(sessionKey)) {
    return false;
  }

  try {
    sessionStorage.setItem(sessionKey, '1');

    // 3. Əgər real istifadəçi daxil olubsa, bir istifadəçidən təkrar baxış gəlməsin deyə Firestore qeydi yoxlanılır
    if (currentUserId) {
      const viewerRef = doc(db, 'videoViews', `${videoId}_${currentUserId}`);
      const viewerSnap = await getDoc(viewerRef);
      if (viewerSnap.exists()) {
        return false;
      }
      await setDoc(viewerRef, {
        videoId,
        viewerId: currentUserId,
        videoOwnerId,
        viewedAt: new Date().toISOString(),
      });
    }

    // 4. Real vaxtda Firestore-da baxış sayını 1 artırırıq (bütün istifadəçilərin ekranında anında dəyişir)
    const videoRef = doc(db, VIDEOS_COL, videoId);
    await updateDoc(videoRef, {
      views: increment(1),
    });

    // 5. Cloud SQL verilənlər bazası ilə sinxronizasiya
    fetch(`/api/videos/${videoId}/view`, { method: 'POST' }).catch(() => {});
    return true;
  } catch (err) {
    console.warn('Baxış sayı artırılarkən xəbərdarlıq:', err);
    return false;
  }
}

// Like / Dislike reactions
export async function toggleVideoReaction(
  videoId: string,
  userId: string,
  newType: 'like' | 'dislike' | null,
  prevType: 'like' | 'dislike' | null
): Promise<void> {
  const reactionId = `like_${userId}_${videoId}`;
  const videoRef = doc(db, VIDEOS_COL, videoId);

  try {
    if (newType === null) {
      // Remove reaction
      await deleteDoc(doc(db, LIKES_COL, reactionId));
      if (prevType === 'like') {
        await updateDoc(videoRef, { likes: increment(-1) });
      } else if (prevType === 'dislike') {
        await updateDoc(videoRef, { dislikes: increment(-1) });
      }
    } else {
      await setDoc(doc(db, LIKES_COL, reactionId), {
        id: reactionId,
        userId,
        videoId,
        type: newType,
        createdAt: new Date().toISOString(),
      });

      if (prevType === 'like' && newType === 'dislike') {
        await updateDoc(videoRef, { likes: increment(-1), dislikes: increment(1) });
      } else if (prevType === 'dislike' && newType === 'like') {
        await updateDoc(videoRef, { likes: increment(1), dislikes: increment(-1) });
      } else if (!prevType && newType === 'like') {
        await updateDoc(videoRef, { likes: increment(1) });
      } else if (!prevType && newType === 'dislike') {
        await updateDoc(videoRef, { dislikes: increment(1) });
      }
    }
  } catch (error) {
    console.warn('Reaction update warning:', error);
  }
}

export async function getUserReaction(videoId: string, userId: string): Promise<'like' | 'dislike' | null> {
  try {
    const reactionId = `like_${userId}_${videoId}`;
    const snap = await getDoc(doc(db, LIKES_COL, reactionId));
    if (snap.exists()) {
      return (snap.data() as any).type;
    }
    return null;
  } catch {
    return null;
  }
}

// Comments
export function subscribeComments(videoId: string, callback: (comments: Comment[]) => void) {
  try {
    const q = query(collection(db, COMMENTS_COL), where('videoId', '==', videoId));
    return onSnapshot(
      q,
      (snapshot) => {
        const list: Comment[] = [];
        snapshot.forEach((d) => {
          list.push({ ...(d.data() as Comment), id: d.id });
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        callback(list);
      },
      (error) => {
        console.warn('Comments listener error:', error);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, COMMENTS_COL);
  }
}

export async function addComment(comment: Omit<Comment, 'id'>): Promise<string> {
  const commentId = `comm_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  try {
    await setDoc(doc(db, COMMENTS_COL, commentId), {
      ...comment,
      id: commentId,
    });
    return commentId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${COMMENTS_COL}/${commentId}`);
    return commentId;
  }
}

export async function deleteCommentById(commentId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, COMMENTS_COL, commentId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${COMMENTS_COL}/${commentId}`);
  }
}

// Channels
export async function getOrCreateChannel(userId: string, name: string, avatar?: string, email?: string): Promise<Channel> {
  const channelRef = doc(db, CHANNELS_COL, userId);
  try {
    const snap = await getDoc(channelRef);
    if (snap.exists()) {
      return snap.data() as Channel;
    }

    const cleanHandle = `@${(email ? email.split('@')[0] : name).toLowerCase().replace(/[^a-z0-9_]/g, '') || 'user'}`;
    const newChannel: Channel = {
      id: userId,
      name: name || 'Yeni Kanal',
      handle: cleanHandle,
      avatar: avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      bannerUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=1280&q=80',
      bio: 'AzTube video paylaşım platformasındakı rəsmi kanalım.',
      subscribersCount: 1,
      createdAt: new Date().toISOString(),
    };

    await setDoc(channelRef, newChannel);
    return newChannel;
  } catch (error) {
    console.warn('Channel fetch/create warning:', error);
    return {
      id: userId,
      name,
      handle: `@${name.toLowerCase().replace(/\s+/g, '')}`,
      avatar,
      subscribersCount: 1,
      createdAt: new Date().toISOString(),
    };
  }
}

export async function updateChannelProfile(userId: string, data: Partial<Channel>): Promise<void> {
  try {
    const channelRef = doc(db, CHANNELS_COL, userId);
    await updateDoc(channelRef, data);
  } catch (err) {
    console.warn('Update channel error:', err);
  }
}

// Subscriptions
export function subscribeUserSubscriptions(userId: string, callback: (channelIds: string[]) => void) {
  try {
    const q = query(collection(db, SUBS_COL), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snapshot) => {
        const ids: string[] = [];
        snapshot.forEach((d) => {
          ids.push((d.data() as any).channelId);
        });
        callback(ids);
      },
      (error) => {
        console.warn('Subscriptions listener error:', error);
        callback([]);
      }
    );
  } catch (error) {
    console.warn('Subscriptions query error:', error);
  }
}

export async function toggleSubscription(userId: string, channelId: string, isSubscribed: boolean): Promise<void> {
  const subId = `sub_${userId}_${channelId}`;
  const channelRef = doc(db, CHANNELS_COL, channelId);

  try {
    if (isSubscribed) {
      await deleteDoc(doc(db, SUBS_COL, subId));
      await updateDoc(channelRef, { subscribersCount: increment(-1) }).catch(() => {});
    } else {
      await setDoc(doc(db, SUBS_COL, subId), {
        id: subId,
        userId,
        channelId,
        createdAt: new Date().toISOString(),
      });
      await updateDoc(channelRef, { subscribersCount: increment(1) }).catch(() => {});
    }
  } catch (error) {
    console.warn('Subscription toggle warning:', error);
  }
}

// Watch Later
export function subscribeWatchLater(userId: string, callback: (items: WatchLaterItem[]) => void) {
  try {
    const q = query(collection(db, WATCH_LATER_COL), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snapshot) => {
        const list: WatchLaterItem[] = [];
        snapshot.forEach((d) => {
          list.push({ ...(d.data() as WatchLaterItem), id: d.id });
        });
        callback(list);
      },
      (error) => {
        console.warn('Watch later listener error:', error);
        callback([]);
      }
    );
  } catch (error) {
    console.warn('Watch later query error:', error);
  }
}

export async function toggleWatchLater(userId: string, video: Video, isSaved: boolean): Promise<void> {
  const id = `wl_${userId}_${video.id}`;
  try {
    if (isSaved) {
      await deleteDoc(doc(db, WATCH_LATER_COL, id));
    } else {
      await setDoc(doc(db, WATCH_LATER_COL, id), {
        id,
        userId,
        videoId: video.id,
        videoTitle: video.title,
        thumbnailUrl: video.thumbnailUrl,
        createdAt: new Date().toISOString(),
      });
    }
  } catch (error) {
    console.warn('Watch later toggle error:', error);
  }
}
