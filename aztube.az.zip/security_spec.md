# Security Specification

## 1. Data Invariants
- Movies can be viewed publicly by any visitor.
- Only authorized administrators (matching verified admin email `oruclirzayev4@gmail.com` or admin record) can create, update, or delete movie catalog records.
- Any authenticated user can create comments/reviews on existing movies, with strict schema validation (string lengths, rating 1-10, valid author match).
- Users can manage (read, create, delete) their own watchlist entries where `userId == request.auth.uid`.

## 2. The Dirty Dozen Payloads & Defenses
1. **Unauthenticated Movie Creation**: Attempt to add a movie without auth -> Rejected (write requires admin).
2. **Standard User Movie Modification**: Authenticated non-admin attempts to edit movie title -> Rejected (requires admin).
3. **Malicious Giant Movie Title (>200 chars)**: Admin or attacker sends 50KB string -> Rejected by size check.
4. **Forged Comment User ID**: User 'alice' creates comment with `userId: 'bob'` -> Rejected (`incoming().userId == request.auth.uid`).
5. **Junk Character Document ID**: ID containing invalid characters or > 128 chars -> Rejected by `isValidId()`.
6. **Negative or Absurd Rating in Comment**: Rating set to 999 or -5 -> Rejected by `rating >= 1 && rating <= 10`.
7. **Watchlist Scraping**: User attempts to list all watchlists belonging to other users -> Rejected by `resource.data.userId == request.auth.uid`.
8. **Watchlist Hijacking**: User attempts to delete or write another user's watchlist item -> Rejected.
9. **Shadow Field Injection**: Attempt to write undocumented system properties -> Rejected by strict key validation.
10. **Email Spoofing Attack**: Claiming admin email without `email_verified == true` -> Rejected.
11. **Overly Long Comment Payload**: Comment text exceeding 2000 characters -> Rejected.
12. **Comment Deletion by Other Non-Admin**: Non-owner non-admin deletes someone else's comment -> Rejected.
